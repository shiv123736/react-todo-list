// local reviews data
const reviews = [
    {
        id:1,
        name: 'Kylie Jenner',
        job: 'Web Developer',
        img: 'images/user-1.png',
        text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita, ad. Ratione, nam modi delectus neque oluptatibus debitis consectetur sint consequatur sunt unde voluptate ex! Et nemo non vitae eaque accusantium!',
    },
    {
        id:2,
        name: 'John',
        job: 'Back end Developer',
        img: 'images/user-2.png',
        text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita, ad. Ratione, nam modi delectus neque oluptatibus debitis consectetur sint consequatur sunt unde voluptate ex! Et nemo non vitae eaque accusantium!',

    },
    {
        id:3,
        name: 'Micheal',
        job: 'Front end Developer',
        img: 'images/user-3.png',
        text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita, ad. Ratione, nam modi delectus neque oluptatibus debitis consectetur sint consequatur sunt unde voluptate ex! Et nemo non vitae eaque accusantium!',

    },
 ];

 var author = document.getElementById('author');
 var image = document.getElementById('person-img');
 var job = document.getElementById('job');
 var info = document.getElementById('info');
// buttons 
var next = document.querySelector('.next-btn'); 
var prev = document.querySelector('.prev-btn'); 
var surprise = document.getElementById('random');
var count = 0;

window.addEventListener('DOMContentLoaded', () => {
    showContent(count);
})


next.addEventListener('click', () => {
    if(count < reviews.length-1)
        count++;    
    showContent(count);
});

prev.addEventListener('click', () => {
    if(count > 0) 
        count--;
    showContent(count);
});

surprise.addEventListener('click', () => {
    var randomNo = Math.floor(Math.random() * reviews.length);
    showContent(randomNo);
})

function showContent(no) {
    author.innerText = reviews[no].name; 
    image.src = reviews[no].img;
    job.innerText = reviews[no].job;
    info.innerText = reviews[no].text;
}